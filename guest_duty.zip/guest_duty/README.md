# guest_duty
POC
