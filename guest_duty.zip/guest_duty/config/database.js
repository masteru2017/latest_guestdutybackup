module.exports = {
    'secret': 'devdacticIsAwesome',
     'database': 'mongodb://localhost/guest_Duty'
};

